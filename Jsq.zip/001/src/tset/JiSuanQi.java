package tset;

import javafx.beans.property.ObjectProperty;
import java.math.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author 29431
 */

public class JiSuanQi extends JFrame implements ActionListener{

    /**北面控件**/
    private JPanel jp_north = new JPanel();
    private JTextField input_text = new JTextField();
    private JButton c_btn = new JButton("C");

    /**中间控件**/
    private JPanel jp_center = new JPanel();

    public JiSuanQi() throws HeadlessException {
        this.init();
        this.addNorthcomponent();
        this.addCenterButton();
    }

    public void init(){
        this.setTitle("简易计算器");
        this.setSize(300,300);
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLocationRelativeTo(null);


    }

    //北面控件
    public void addNorthcomponent(){
        this.input_text.setPreferredSize(new Dimension(230,30));
        jp_north.add(input_text);

        this.c_btn.setBackground(Color.cyan);
        jp_north.add(c_btn);

        c_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input_text.setText("");
            }
        });

        this.add(jp_north,BorderLayout.NORTH);
    }


    //添加中间按键
    public void addCenterButton(){
        String btn_text ="123+456-789*0.=/";
        String regex = "[\\+\\-/*.=]";
        this.jp_center.setLayout(new GridLayout(4,4));
        for(int i=0; i<16; i++){
            String temp = btn_text.substring(i,i+1);
            JButton btn = new JButton();
            btn.setText(temp);
           if(temp.matches(regex)){
               btn.setFont(new Font("粗体", Font.BOLD,16));
               btn.setForeground(Color.red);
           }
           btn.addActionListener(this);
           jp_center.add(btn);
        }
        this.add(jp_center,BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JiSuanQi jiSuanQi = new JiSuanQi();
        jiSuanQi.setVisible(true);
    }

    private String firstInput = null;
    private String operator = null;
    @Override
    public void actionPerformed(ActionEvent e) {
        String clickStr = e.getActionCommand();
        if(".0123456789".indexOf(clickStr) != -1){
            this.input_text.setText(input_text.getText()+clickStr);
            this.input_text.setHorizontalAlignment(JTextField.RIGHT);
        }else if(clickStr.matches("[+\\-*/]")){
            operator = clickStr;
            firstInput = this.input_text.getText();
            this.input_text.setText("");
        }else if(clickStr.equals("=")){
            BigInteger a = BigInteger.valueOf(Long.parseLong(firstInput));
            BigInteger b = BigInteger.valueOf(Long.parseLong(this.input_text.getText()));
            BigInteger result = null;
            switch (operator){
                case "+":
                    result = a.add(b);
                    break;
                case "-":
                    result = a.subtract(b);
                    break;
                case "*":
                    result = a.multiply(b);
                    break;
                case "/":
                    if(b.equals(BigDecimal.ZERO)){
                        result = a.divide(b);
                    }
                    break;
                default:
            }
            this.input_text.setText(result.toString());
        }
    }
}